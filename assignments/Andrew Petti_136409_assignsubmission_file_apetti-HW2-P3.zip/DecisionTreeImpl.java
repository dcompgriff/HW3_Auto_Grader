import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Fill in the implementation details of the class DecisionTree using this file. Any methods or
 * secondary classes that you want are fine but we will only interact with those methods in the
 * DecisionTree framework.
 * 
 * You must add code for the 1 member and 4 methods specified below.
 * 
 * See DecisionTree for a description of default methods.
 */
public class DecisionTreeImpl{
	private DecTreeNode root;
	//ordered list of attributes
	private List<String> mTrainAttributes; 
	//
	private ArrayList<ArrayList<Double>> mTrainDataSet;
	//Min number of instances per leaf.
	private int minLeafNumber = 10;

	/**
	 * Answers static questions about decision trees.
	 */
	DecisionTreeImpl() {
		// no code necessary this is void purposefully
	}

	/**
	 * Build a decision tree given a training set then prune it using a tuning set.
	 * 
	 * @param train: the training set
	 * @param tune: the tuning set
	 */
	DecisionTreeImpl(ArrayList<ArrayList<Double>> trainDataSet, ArrayList<String> trainAttributeNames, int minLeafNumber) {
		this.mTrainAttributes = trainAttributeNames;
		this.mTrainDataSet = trainDataSet;
		this.minLeafNumber = minLeafNumber;
		this.root = buildTree(this.mTrainDataSet);
	}
	
	private DecTreeNode buildTree(ArrayList<ArrayList<Double>> dataSet){
		// TODO: add code here
		int classCount = dataSet.stream().mapToInt(o -> o.get(o.size()-1).intValue()).sum();
		//If pure class, build node, set left and right equal to null, set node class, and return the node.
		if(classCount == dataSet.size() || classCount == 0){
			//Pure set of data, so create a leaf node.
			DecTreeNode newNode = new DecTreeNode((classCount == 0 ? 0 : 1), "", 0);
			return newNode;
		}else if(dataSet.size() <= this.minLeafNumber){
			//Less than min leaf threshold, build node, set left and right equal to null, set node class as majority vote, 
			//and return the node.
			int classLabel;
			if(classCount >= dataSet.size()/2){
				classLabel = 1;
			}else{
				classLabel = 0;
			}
			DecTreeNode newNode = new DecTreeNode(classLabel, "", 0);
			return newNode;
		}else{
			//Make best split point list.
			//For each attribute index.
				//Copy original data set and sort by attribute value.
				//Loop over all rows and find class label differences, and add new split point to candidate list.
				//For each candidate split point, try a split and calculate the resulting info gain.
					//If info gain higher than current info gain max, set best split point to current split point.
				//Add InfoGain and SplitPoint tuple to list at index corresponding to the attribute it is for.
			//Find max info gain. If tie, split on the attribute found later in the attribute list.
			//Perform data split based on split point, create new node, set it's attribute label and split point threshold.
			//Recursively call buildTree for left and right data sets.
			//Add left and right children from recursive calls to node, and return the current node.

			
			//Make best split point list. bestSplitPointList[i][0] is entropy for attr i, bestSplitPointList[i][1] is split point.
			double[][] bestSplitPointList = new double[dataSet.get(0).size() - 1][2];
			//Calculate initial class entropy.
			double initialClassEntropy = calculateEntropy(dataSet);
			
			//For each attribute index, excluding last column since that is class label.
			for(int i=0; i<dataSet.get(0).size() - 1; i++){
				ArrayList<DataBinder> listToSort = new ArrayList<DataBinder>();
				for(int j=0; j<dataSet.size(); j++){
					listToSort.add(new DataBinder(i, new ArrayList<Double>(dataSet.get(j))));
				}
				ArrayList<DataBinder> sortedList = (ArrayList<DataBinder>) 
						listToSort.stream().sorted(new Comparator<DataBinder>() {

							@Override
							public int compare(DataBinder o1, DataBinder o2) {
								if(o1.getArgItem() > o2.getArgItem()){
									return 1;
								}else if(o1.getArgItem() < o2.getArgItem()){
									return -1;
								}else{
									return 0;
								}
							}
						}).collect(Collectors.toList());
				ArrayList<ArrayList<Double>> sortedDataSet = new ArrayList<ArrayList<Double>>();
				for(int j=0; j<sortedList.size(); j++){
					sortedDataSet.add(sortedList.get(j).getData());
				}
				
				//Loop over all rows and find class label differences, and add new split point to candidate list.
				ArrayList<Double> candidateSplitPointList = new ArrayList<Double>();
				for(int j=1; j< sortedDataSet.size(); j++){
					if(sortedDataSet.get(j).get(sortedDataSet.get(j).size() - 1) != sortedDataSet.get(j-1).get(sortedDataSet.get(j-1).size() - 1)){
						candidateSplitPointList.add((sortedDataSet.get(j).get(i) + sortedDataSet.get(j-1).get(i))/2.0);
					}
				}
				//For each candidate split point, try a split and calculate the resulting info gain.
				double bestInfoGain = 0;
				double bestSplitPoint = 0;
				for(double candidateThreshold : candidateSplitPointList){
					ArrayList<ArrayList<Double>> lessThanOrEqual = new ArrayList<ArrayList<Double>>();
					ArrayList<ArrayList<Double>> greaterThan = new ArrayList<ArrayList<Double>>();
					for(int j = 0; j<dataSet.size(); j++){
						if(dataSet.get(j).get(i) <= candidateThreshold){
							lessThanOrEqual.add(dataSet.get(j));
						}else{
							greaterThan.add(dataSet.get(j));
						}
					}
					double leftEntropy = calculateEntropy(lessThanOrEqual);
					double rightEntropy = calculateEntropy(greaterThan);
					double newInfoGain = initialClassEntropy - ((lessThanOrEqual.size()/(double)dataSet.size())*leftEntropy) - 
							((greaterThan.size()/(double)dataSet.size())*rightEntropy);
					if(newInfoGain >= bestInfoGain){
						bestInfoGain = newInfoGain;
						bestSplitPoint = candidateThreshold;
					}	
				}
				//Add InfoGain and SplitPoint tuple to list at index corresponding to the attribute it is for.
				bestSplitPointList[i][0] = bestInfoGain;
				bestSplitPointList[i][1] = bestSplitPoint;
			}
			
			//Find max info gain. If tie, split on the attribute found later in the attribute list.
			double bestInfoGain = 0;
			int bestInfoGainAttr = 0;
			for(int i = 0; i<bestSplitPointList.length; i++){
				if(bestSplitPointList[i][0] >= bestInfoGain){
					bestInfoGain = bestSplitPointList[i][0];
					bestInfoGainAttr = i;
				}
			}
			//Perform data split based on split point, create new node, set it's attribute label and split point threshold.
			ArrayList<ArrayList<Double>> lessThanOrEqual = new ArrayList<ArrayList<Double>>();
			ArrayList<ArrayList<Double>> greaterThan = new ArrayList<ArrayList<Double>>();
			double threshold = bestSplitPointList[bestInfoGainAttr][1];
			for(int i = 0; i<dataSet.size(); i++){
				if(dataSet.get(i).get(bestInfoGainAttr) <= threshold){
					lessThanOrEqual.add(dataSet.get(i));
				}else{
					greaterThan.add(dataSet.get(i));
				}
			}
			DecTreeNode newNode = new DecTreeNode(-1, this.mTrainAttributes.get(bestInfoGainAttr), threshold);
			//Recursively call buildTree for left and right data sets.
			newNode.left = buildTree(lessThanOrEqual);
			newNode.right = buildTree(greaterThan);
			return newNode;
		}
	}
	
	
	public int classify(List<Double> instance) {
		// TODO: add code here
		DecTreeNode currentNode = this.root;
		while(!currentNode.isLeaf()){
			int attrSplitIndex = this.mTrainAttributes.indexOf(currentNode.attribute);
			if(instance.get(attrSplitIndex) <= currentNode.threshold){
				currentNode = currentNode.left;
			}else{
				currentNode = currentNode.right;
			}
		}
		return currentNode.classLabel;
	}

	public double calculateEntropy(ArrayList<ArrayList<Double>> dataSet){
		//Assume class label in last pos in each row, and that class labels are 0 and 1.
		int classCount = dataSet.stream().mapToInt(o -> o.get(o.size()-1).intValue()).sum();
		int zeroCount = dataSet.size() - classCount;
		int oneCount = classCount;
		double onesProb = (double)oneCount/dataSet.size();
		double zerosProb = (double)zeroCount/dataSet.size();
		
		if(zeroCount == 0 || oneCount == 0){
			return 0;
		}else{
			return ((-1.0*onesProb)*(Math.log10(onesProb)/Math.log10(2.0))) + ((-1.0*zerosProb)*(Math.log10(zerosProb)/Math.log10(2.0)));
		}
	}
	
	public void rootInfoGain(ArrayList<ArrayList<Double>> dataSet, ArrayList<String> trainAttributeNames, int minLeafNumber) {
		this.mTrainAttributes = trainAttributeNames;
		this.mTrainDataSet = dataSet;
		this.minLeafNumber = minLeafNumber;
		// TODO: add code here
		
		//Make best split point list. bestSplitPointList[i][0] is entropy for attr i, bestSplitPointList[i][1] is split point.
		double[][] bestSplitPointList = new double[dataSet.get(0).size() - 1][2];
		//Calculate initial class entropy.
		double initialClassEntropy = calculateEntropy(dataSet);
		
		//For each attribute index, excluding last column since that is class label.
		for(int i=0; i<dataSet.get(0).size() - 1; i++){
			ArrayList<DataBinder> listToSort = new ArrayList<DataBinder>();
			for(int j=0; j<dataSet.size(); j++){
				listToSort.add(new DataBinder(i, new ArrayList<Double>(dataSet.get(j))));
			}
			ArrayList<DataBinder> sortedList = (ArrayList<DataBinder>) 
					listToSort.stream().sorted(new Comparator<DataBinder>() {

						@Override
						public int compare(DataBinder o1, DataBinder o2) {
							if(o1.getArgItem() > o2.getArgItem()){
								return 1;
							}else if(o1.getArgItem() < o2.getArgItem()){
								return -1;
							}else{
								return 0;
							}
						}
					}).collect(Collectors.toList());
			ArrayList<ArrayList<Double>> sortedDataSet = new ArrayList<ArrayList<Double>>();
			for(int j=0; j<sortedList.size(); j++){
				sortedDataSet.add(sortedList.get(j).getData());
			}
			
			//Loop over all rows and find class label differences, and add new split point to candidate list.
			ArrayList<Double> candidateSplitPointList = new ArrayList<Double>();
			for(int j=1; j< sortedDataSet.size(); j++){
				if(sortedDataSet.get(j).get(sortedDataSet.get(j).size() - 1) != sortedDataSet.get(j-1).get(sortedDataSet.get(j-1).size() - 1)){
					candidateSplitPointList.add((sortedDataSet.get(j).get(i) + sortedDataSet.get(j-1).get(i))/2.0);
				}
			}
			//For each candidate split point, try a split and calculate the resulting info gain.
			double bestInfoGain = 0;
			double bestSplitPoint = 0;
			for(double candidateThreshold : candidateSplitPointList){
				ArrayList<ArrayList<Double>> lessThanOrEqual = new ArrayList<ArrayList<Double>>();
				ArrayList<ArrayList<Double>> greaterThan = new ArrayList<ArrayList<Double>>();
				for(int j = 0; j<dataSet.size(); j++){
					if(dataSet.get(j).get(i) <= candidateThreshold){
						lessThanOrEqual.add(dataSet.get(j));
					}else{
						greaterThan.add(dataSet.get(j));
					}
				}
				double leftEntropy = calculateEntropy(lessThanOrEqual);
				double rightEntropy = calculateEntropy(greaterThan);
				double newInfoGain = initialClassEntropy - ((lessThanOrEqual.size()/(double)dataSet.size())*leftEntropy) - 
						((greaterThan.size()/(double)dataSet.size())*rightEntropy);
				if(newInfoGain >= bestInfoGain){
					bestInfoGain = newInfoGain;
					bestSplitPoint = candidateThreshold;
				}	
			}
			//Add InfoGain and SplitPoint tuple to list at index corresponding to the attribute it is for.
			bestSplitPointList[i][0] = bestInfoGain;
			bestSplitPointList[i][1] = bestSplitPoint;
		}
		
		//Find max info gain. If tie, split on the attribute found later in the attribute list.
		double bestInfoGain = 0;
		int bestInfoGainAttr = 0;
		for(int i = 0; i<bestSplitPointList.length; i++){
			if(bestSplitPointList[i][0] >= bestInfoGain){
				bestInfoGain = bestSplitPointList[i][0];
				bestInfoGainAttr = i;
			}
		}
		//Perform data split based on split point, create new node, set it's attribute label and split point threshold.
		ArrayList<ArrayList<Double>> lessThanOrEqual = new ArrayList<ArrayList<Double>>();
		ArrayList<ArrayList<Double>> greaterThan = new ArrayList<ArrayList<Double>>();
		double threshold = bestSplitPointList[bestInfoGainAttr][1];
		for(int i = 0; i<dataSet.size(); i++){
			if(dataSet.get(i).get(bestInfoGainAttr) <= threshold){
				lessThanOrEqual.add(dataSet.get(i));
			}else{
				greaterThan.add(dataSet.get(i));
			}
		}
		
		//Print the attribute and info gain on separate lines.
		for(int i = 0; i<bestSplitPointList.length; i++){
			System.out.println(this.mTrainAttributes.get(i) + " " + String.format("%.6f", bestSplitPointList[i][0]));
		}
		
	}

	
	/**
	 * Print the decision tree in the specified format
	 */
	public void print() {
		printTreeNode("", this.root);
	}

	/**
	 * Prints the subtree of the node with each line prefixed by 4 * k spaces.
	 */
	public void printTreeNode(String prefixStr, DecTreeNode node) {
		String printStr = prefixStr + node.attribute;
			
		System.out.print(printStr + " <= " + String.format("%.6f", node.threshold));
		if(node.left.isLeaf()){
			System.out.println(": " + String.valueOf(node.left.classLabel));
		}else{
			System.out.println();
			printTreeNode(prefixStr + "|\t", node.left);
		}
		System.out.print(printStr + " > " + String.format("%.6f", node.threshold));
		if(node.right.isLeaf()){
			System.out.println(": " + String.valueOf(node.right.classLabel));
		}else{
			System.out.println();
			printTreeNode(prefixStr + "|\t", node.right);
		}
		
		
	}
	
	public double printAccuracy(int numEqual, int numTotal){
		double accuracy = numEqual/(double)numTotal;
		System.out.println(accuracy);
		return accuracy;
	}

	/**
	 * Private class to facilitate instance sorting by argument position since java doesn't like passing variables to comparators through
	 * nested variable scopes.
	 * */
	private class DataBinder{
		
		public ArrayList<Double> mData;
		public int i;
		public DataBinder(int i, ArrayList<Double> mData){
			this.mData = mData;
			this.i = i;
		}
		public double getArgItem(){
			return mData.get(i);
		}
		public ArrayList<Double> getData(){
			return mData;
		}
		
	}

}
